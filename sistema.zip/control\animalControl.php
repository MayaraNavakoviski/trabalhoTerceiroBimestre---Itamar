<?php
require_once("../model/animal.php");
require_once("../dao/animalDao.php");
class AnimalControl {
    private $animal;
    private $acao;
    private $dao;
    public function __construct(){
       $this->animal=new Animal();
      $this->dao=new AnimalDao();
      $this->acao=$_GET["a"];
      $this->verificaAcao(); 
    }
    function verificaAcao(){
       switch($this->acao){
          case 1:
            $this->inserir();
          break;
          case 2:
            $this->excluir();
          break;
          case 3:
            $this->alterar();
          break;
       }
    }
  
    function inserir(){
        $this->animal->setNome($_POST['nome']);
		$this->animal->setDono($_POST['dono']);
		$this->animal->setRaca($_POST['raca']);
		$this->animal->setNumero($_POST['numero']);
		$this->animal->setSexo($_POST['sexo']);
		$this->animal->setServico($_POST['servico']);
		$this->animal->setDia($_POST['dia']);
		$this->animal->setHora($_POST['hora']);
		$this->animal->setEspecie($_POST['especie']);
		$this->animal->setImagem($_POST['imagem']);
		
        $this->dao->inserir($this->animal);
    }
    function excluir(){
        $this->dao->excluir($_REQUEST['id']);
    }
    function alterar(){
        $this->animal->setNome($_POST['nome']);
		$this->animal->setDono($_POST['dono']);
		$this->animal->setRaca($_POST['raca']);
		$this->animal->setNumero($_POST['numero']);
		$this->animal->setSexo($_POST['sexo']);
		$this->animal->setServico($_POST['servico']);
		$this->animal->setDia($_POST['dia']);
		$this->animal->setHora($_POST['hora']);
		$this->animal->setEspecie($_POST['especie']);
		$this->animal->setImagem($_POST['imagem']);
		
        $idValue = $_REQUEST['id']; 
        if ($idValue) {
             $this->dao->alterar($this->animal, $idValue);
        } else {
             header("Location:../view/listaAnimal.php?erro=id_ausente"); 
        }

    }

}
new AnimalControl();
?>