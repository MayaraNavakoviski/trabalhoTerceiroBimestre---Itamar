<?php
require_once("../model/conexao.php");
class AnimalDao {
    private $con;
    public function __construct(){
       $this->con=(new Conexao())->conectar();
    }
function inserir($obj) {
    $sql = "INSERT INTO animal (nome, dono, raca, numero, sexo, servico, dia, hora, especie, imagem) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $this->con->prepare($sql);
    $nome=$obj->getNome();
$dono=$obj->getDono();
$raca=$obj->getRaca();
$numero=$obj->getNumero();
$sexo=$obj->getSexo();
$servico=$obj->getServico();
$dia=$obj->getDia();
$hora=$obj->getHora();
$especie=$obj->getEspecie();
$imagem=$obj->getImagem();

    $stmt->execute([$nome,$dono,$raca,$numero,$sexo,$servico,$dia,$hora,$especie,$imagem]);
    header("Location:../view/listaAnimal.php");
}

function listaGeral(){
    $sql = "select * from animal";
    $query = $this->con->query($sql);
    $dados = $query->fetchAll(PDO::FETCH_ASSOC);
    return $dados;
}

function excluir($id){
    $sql = "delete from animal where id=$id";
    $query = $this->con->query($sql);
    header("Location:../view/listaAnimal.php");
}

function buscaPorId($id){
    $sql = "select * from animal where id = :id";
    $stmt = $this->con->prepare($sql);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $dados = $stmt->fetch(PDO::FETCH_ASSOC);
    return $dados;
}

function alterar($obj, $idValue){
    $sql = "UPDATE animal SET nome=?, dono=?, raca=?, numero=?, sexo=?, servico=?, dia=?, hora=?, especie=?, imagem=? WHERE id=?";
    $stmt = $this->con->prepare($sql);
    $nome=$obj->getNome();
$dono=$obj->getDono();
$raca=$obj->getRaca();
$numero=$obj->getNumero();
$sexo=$obj->getSexo();
$servico=$obj->getServico();
$dia=$obj->getDia();
$hora=$obj->getHora();
$especie=$obj->getEspecie();
$imagem=$obj->getImagem();

    $stmt->execute([$nome,$dono,$raca,$numero,$sexo,$servico,$dia,$hora,$especie,$imagem, $idValue]); 
    header("Location:../view/listaAnimal.php");
}
}
?>