<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mayara - Menu Principal</title>
    <link rel="stylesheet" href="./css/style.css"> 
</head>
<body class="sistema-principal">
    <div class="header">
        <div class="header-content">
            <div class="logo">Mayara</div>
            
            <nav class="navbar">
                <ul class="nav-menu">
                    <li class="nav-item">
                        <a href="#" class="nav-link">Cadastros</a>
                        <div class="dropdown">
                            <a href='./view/animal.php' class='dropdown-link' target='iframe' >Cadastro de Animal</a>

                        </div>
                    </li>
                    
                    <li class="nav-item">
                        <a href="#" class="nav-link">Relatórios</a>
                        <div class="dropdown">
                            <a href='./view/listaAnimal.php' class='dropdown-link' target='iframe'>Lista de Animal</a>

                        </div>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
    
    <div class="main-content">
        <div class="content-wrapper">
            <div class="iframe-container">
                <iframe id="contentFrame" name="iframe" src="inicio.html" seamless>
                    Seu navegador não suporta iframes.
                </iframe>
            </div>
        </div>
    </div>

</body>
</html>