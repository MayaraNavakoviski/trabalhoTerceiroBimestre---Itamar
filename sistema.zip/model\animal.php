<?php
class Animal {
	private $id;
	private $nome;
	private $dono;
	private $raca;
	private $numero;
	private $sexo;
	private $servico;
	private $dia;
	private $hora;
	private $especie;
	private $imagem;

	function getId(){
		return $this->id;
	}
	function setId($id){
		$this->id=$id;
	}
	function getNome(){
		return $this->nome;
	}
	function setNome($nome){
		$this->nome=$nome;
	}
	function getDono(){
		return $this->dono;
	}
	function setDono($dono){
		$this->dono=$dono;
	}
	function getRaca(){
		return $this->raca;
	}
	function setRaca($raca){
		$this->raca=$raca;
	}
	function getNumero(){
		return $this->numero;
	}
	function setNumero($numero){
		$this->numero=$numero;
	}
	function getSexo(){
		return $this->sexo;
	}
	function setSexo($sexo){
		$this->sexo=$sexo;
	}
	function getServico(){
		return $this->servico;
	}
	function setServico($servico){
		$this->servico=$servico;
	}
	function getDia(){
		return $this->dia;
	}
	function setDia($dia){
		$this->dia=$dia;
	}
	function getHora(){
		return $this->hora;
	}
	function setHora($hora){
		$this->hora=$hora;
	}
	function getEspecie(){
		return $this->especie;
	}
	function setEspecie($especie){
		$this->especie=$especie;
	}
	function getImagem(){
		return $this->imagem;
	}
	function setImagem($imagem){
		$this->imagem=$imagem;
	}

}
?>