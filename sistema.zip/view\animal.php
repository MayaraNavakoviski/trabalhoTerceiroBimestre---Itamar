<?php
    require_once('../dao/animalDao.php');
    $obj=null;
    if(isset($_GET['id']))
        $obj=(new animalDao())->buscaPorId($_GET['id']);

    $acao=$obj? 3:1; 
    $nome = $acao == 1 ? "Cadastrar" : "Editar";
?>
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?= $nome ?> de Animal</title>
        <link rel="stylesheet" href="../css/style.css"> 
    </head>
    <body class="form-page">
        <div class="container form-cadastro">
            <form id="form-animal" class="form-moderno" action="../control/animalControl.php?a=<?php echo $acao ?><?php if(isset($_GET['id'])) {echo '&id='.$_GET['id'];} ?>" method="post">
                <h2><?= $nome ?> Animal</h2>
                
<input type='hidden' id='id' name='id' value='<?php echo $obj?$obj['id']:''; ?>'>

<div class="campo-grupo">
<label for='nome'>Nome</label>
<input type='text' id='nome' name='nome' value='<?php echo $obj?$obj['nome']:''; ?>' required>
 </div>

<div class="campo-grupo">
<label for='dono'>Dono</label>
<input type='text' id='dono' name='dono' value='<?php echo $obj?$obj['dono']:''; ?>' required>
 </div>

<div class="campo-grupo">
<label for='raca'>Raca</label>
<input type='text' id='raca' name='raca' value='<?php echo $obj?$obj['raca']:''; ?>' required>
 </div>

<div class="campo-grupo">
<label for='numero'>Numero</label>
<input type='number' id='numero' name='numero' value='<?php echo $obj?$obj['numero']:''; ?>' required>
 </div>

<div class="campo-grupo">
<label for='sexo'>Sexo</label>
<input type='text' id='sexo' name='sexo' value='<?php echo $obj?$obj['sexo']:''; ?>' required>
 </div>

<div class="campo-grupo">
<label for='servico'>Servico</label>
<input type='text' id='servico' name='servico' value='<?php echo $obj?$obj['servico']:''; ?>' required>
 </div>

<div class="campo-grupo">
<label for='dia'>Dia</label>
<input type='date' id='dia' name='dia' value='<?php echo $obj?$obj['dia']:''; ?>' required>
 </div>

<div class="campo-grupo">
<label for='hora'>Hora</label>
<input type='date' id='hora' name='hora' value='<?php echo $obj?$obj['hora']:''; ?>' required>
 </div>

<div class="campo-grupo">
<label for='especie'>Especie</label>
<input type='text' id='especie' name='especie' value='<?php echo $obj?$obj['especie']:''; ?>' required>
 </div>

<div class="campo-grupo">
<label for='imagem'>Imagem</label>
<input type='text' id='imagem' name='imagem' value='<?php echo $obj?$obj['imagem']:''; ?>' >
 </div>

                <button type="submit" class="btn-submit"><?= $acao == 1 ? 'Cadastrar' : 'Atualizar' ?></button>
                <p class="voltar-lista"><a href="listaAnimal.php" target="_top">Voltar para a Lista</a></p>
            </form>
        </div>
    </body>
</html>