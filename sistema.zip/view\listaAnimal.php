<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Lista de Animal</title>
        <link rel="stylesheet" href="../css/style.css"> 
    </head>
    <body class="lista-page">
        <div class="tabela-container">
            <h2>Lista de Animal</h2>
            <a href="animal.php" class="btn btn-novo">+ Novo Animal</a>
            
            <?php
            require_once("../dao/animalDao.php");
            $dao = new animalDAO();
            $dados = $dao->listaGeral();
            
            if (!empty($dados)) {
                echo "<table class='data-table'>";
                echo "<thead><tr>";
                    echo "<th>Id</th>";
    echo "<th>Nome</th>";
    echo "<th>Dono</th>";
    echo "<th>Raca</th>";
    echo "<th>Numero</th>";
    echo "<th>Sexo</th>";
    echo "<th>Servico</th>";
    echo "<th>Dia</th>";
    echo "<th>Hora</th>";
    echo "<th>Especie</th>";
    echo "<th>Imagem</th>";

                echo "<th>Ações</th>";
                echo "</tr></thead>";
                
                echo "<tbody>";
                foreach($dados as $dado) {
                    echo "<tr>";
                        echo "<td>{$dado['id']}</td>";
echo "<td>{$dado['nome']}</td>";
echo "<td>{$dado['dono']}</td>";
echo "<td>{$dado['raca']}</td>";
echo "<td>{$dado['numero']}</td>";
echo "<td>{$dado['sexo']}</td>";
echo "<td>{$dado['servico']}</td>";
echo "<td>{$dado['dia']}</td>";
echo "<td>{$dado['hora']}</td>";
echo "<td>{$dado['especie']}</td>";
echo "<td>{$dado['imagem']}</td>";

                    echo "<td class='actions'>";
                    echo "<a href='animal.php?id={$dado['id']}' class='btn-acao btn-editar'>Editar</a>";
                    echo "<a href='../control/animalControl.php?id={$dado['id']}&a=2' onclick='return confirm(\"Tem certeza que deseja excluir este registro?\")' class='btn-acao btn-excluir'>Excluir</a>";
                    echo "</td>";
                    echo "</tr>";
                }
                echo "</tbody>";
                echo "</table>";
            } else {
                echo "<p class='no-records'>Nenhum registro de Animal encontrado.</p>";
            }
            ?>
        </div>
    </body>
</html>